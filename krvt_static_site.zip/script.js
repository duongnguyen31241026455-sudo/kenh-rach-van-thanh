// Simple static site JS for KRVT
const LS = {
  spots: 'krvt_spots_v1',
  members: 'krvt_members_v1',
  events: 'krvt_events_v1',
  trash: 'krvt_trash_v1',
  rewards: 'krvt_rewards_v1',
  settings: 'krvt_settings_v1'
};

function loadOrDefault(k, d){ try{ const v=localStorage.getItem(k); return v?JSON.parse(v):d }catch(e){return d} }
function save(k,v){ localStorage.setItem(k, JSON.stringify(v)); }

let spots = loadOrDefault(LS.spots, [
  {id:'Cau1', name:'Cầu số 1', level:42, note:'Rác trôi sau mưa'},
  {id:'Cau2', name:'Cầu số 2', level:73, note:'Mùi hôi, nước đục'},
  {id:'Cong3', name:'Cống số 3', level:15, note:'Ổn định'}
]);
let members = loadOrDefault(LS.members, [
  {id:'sv01', name:'Nguyễn Minh Anh', points:40},
  {id:'sv02', name:'Trần Bảo', points:15}
]);
let events = loadOrDefault(LS.events, [
  {id:'evt1', name:'Chủ nhật xanh mẫu', date: new Date().toISOString().slice(0,10), pts:20, attendees:[]}
]);
let trash = loadOrDefault(LS.trash, (function seed(){
  const arr=[]; const now=new Date();
  for(let i=14;i>=0;i--){ const d=new Date(now); d.setDate(now.getDate()-i); arr.push({date:d.toISOString().slice(5,10), bags: Math.floor(8+Math.random()*35), rain: Math.random()<0.3?Math.floor(5+Math.random()*80):0 }) }
  return arr;
})());
let rewards = loadOrDefault(LS.rewards, [
  {id:'rw01', name:'Bình nước tái sử dụng', cost:50},
  {id:'rw02', name:'Áo thun tình nguyện', cost:120},
  {id:'rw03', name:'Móc khóa xanh', cost:20}
]);
let settings = loadOrDefault(LS.settings, {badWeather:false, note:''});

const spotsList = document.getElementById('spotsList');
const spotsCount = document.getElementById('spotsCount');
const avgLevelLabel = document.getElementById('avgLevelLabel');
const addSpotBtn = document.getElementById('addSpot');
const spotNameInput = document.getElementById('spotName');
const spotLevelSelect = document.getElementById('spotLevel');

const membersCount = document.getElementById('membersCount');
const addMemBtn = document.getElementById('addMem');
const memIdInput = document.getElementById('memId');
const memNameInput = document.getElementById('memName');

const createEvtBtn = document.getElementById('createEvt');
const evtName = document.getElementById('evtName');
const evtDate = document.getElementById('evtDate');
const evtPts = document.getElementById('evtPts');
const eventsArea = document.getElementById('eventsArea');

const leaderEl = document.getElementById('leaderboard');
const rewardsList = document.getElementById('rewardsList');

const addFakeDay = document.getElementById('addFakeDay');
const clearData = document.getElementById('clearData');
const weatherBadge = document.getElementById('weatherBadge');
const exportBtn = document.getElementById('exportBtn');

function levelToColor(l){
  if(l<=20) return 'bg-green-500 text-white';
  if(l<=50) return 'bg-yellow-400 text-black';
  if(l<=80) return 'bg-orange-500 text-white';
  return 'bg-red-600 text-white';
}
function levelToLabel(l){ if(l<=20) return 'Tốt'; if(l<=50) return 'Cần chú ý'; if(l<=80) return 'Xấu'; return 'Nguy hại' }

function renderSpots(){
  spotsList.innerHTML='';
  spots.forEach(s=>{
    const div = document.createElement('div');
    div.className='flex items-center justify-between gap-3 p-3 rounded-lg border';
    div.innerHTML = `
      <div>
        <div class="font-semibold">${s.name}</div>
        <div class="text-xs text-gray-500">${s.note||''}</div>
      </div>
      <div class="flex items-center gap-3 min-w-[220px]">
        <div class="${levelToColor(s.level)} rounded-xl w-8 h-8 flex items-center justify-center font-semibold">${s.level}</div>
        <input type="range" min="0" max="100" value="${s.level}" data-id="${s.id}" class="w-40">
        <button class="px-2 py-1 text-sm rounded-md bg-red-100 text-red-700 del-spot" data-id="${s.id}">Xóa</button>
      </div>
    `;
    spotsList.appendChild(div);
  });
  spotsCount.innerText = spots.length;
  document.querySelectorAll('input[type=range][data-id]').forEach(r=>{
    r.addEventListener('input', e=>{
      const id=e.target.getAttribute('data-id'); const v=Number(e.target.value);
      spots = spots.map(s=> s.id===id? {...s, level:v}: s );
      save(LS.spots, spots); updateAvg();
      renderSpots();
    });
  });
  document.querySelectorAll('.del-spot').forEach(b=> b.addEventListener('click', e=>{
    const id=e.target.getAttribute('data-id'); spots = spots.filter(s=>s.id!==id); save(LS.spots, spots); renderSpots();
  }));
}

function addSpotFromForm(){
  const name = spotNameInput.value.trim(); const level = Number(spotLevelSelect.value);
  if(!name){ alert('Nhập tên điểm'); return; }
  const id = 'sp'+Date.now().toString(36);
  spots.push({id, name, level, note:''}); save(LS.spots, spots); spotNameInput.value=''; renderSpots();
}

function renderMembersCount(){ membersCount.innerText = members.length; }
function addMember(){
  const id = memIdInput.value.trim(); const name = memNameInput.value.trim();
  if(!id||!name){ alert('Nhập mã và tên'); return; }
  if(members.some(m=>m.id===id)){ alert('Mã đã tồn tại'); return; }
  members.push({id, name, points:0}); save(LS.members, members); memIdInput.value=''; memNameInput.value=''; renderMembersCount(); renderLeaderboard(); renderEvents();
}

function renderEvents(){
  eventsArea.innerHTML='';
  events.forEach(ev=>{
    const box = document.createElement('div'); box.className='p-3 border rounded-lg';
    box.innerHTML = `
      <div class="flex items-center justify-between">
        <div><div class="font-semibold">${ev.name}</div><div class="text-xs text-gray-500">${ev.date} · +${ev.pts} điểm</div></div>
        <div><button class="px-2 py-1 bg-emerald-600 text-white rounded-md award" data-id="${ev.id}">Cộng điểm</button></div>
      </div>
      <div class="mt-3 p-2 bg-emerald-50 rounded-md">
        <div class="text-sm font-medium mb-2">Điểm danh</div>
        <div class="grid sm:grid-cols-2 gap-2" id="att-${ev.id}"></div>
      </div>
    `;
    eventsArea.appendChild(box);
    const attDiv = document.getElementById('att-'+ev.id);
    members.forEach(m=>{
      const checked = ev.attendees.includes(m.id);
      const label = document.createElement('label');
      label.className = `flex items-center justify-between p-2 rounded-lg border ${checked? 'bg-emerald-100':''}`;
      label.innerHTML = `<span class="text-sm">${m.name} <span class="text-xs text-gray-500">(${m.id})</span></span>`;
      const btn = document.createElement('button'); btn.className='px-2 py-1 rounded switch';
      btn.innerText = checked ? 'Đã điểm danh':'Điểm danh';
      btn.addEventListener('click', ()=>{ toggleAttend(ev.id, m.id); });
      label.appendChild(btn);
      attDiv.appendChild(label);
    });
  });
  document.querySelectorAll('.award').forEach(b=> b.addEventListener('click', e=>{
    const id = e.target.getAttribute('data-id'); awardPoints(id);
  }));
}

function toggleAttend(eventId, personId){
  events = events.map(e=>{
    if(e.id!==eventId) return e;
    const set = new Set(e.attendees);
    if(set.has(personId)) set.delete(personId); else set.add(personId);
    return {...e, attendees:Array.from(set)};
  });
  save(LS.events, events); renderEvents();
}

function awardPoints(eventId){
  const ev = events.find(e=>e.id===eventId); if(!ev) return;
  members = members.map(m=> ev.attendees.includes(m.id) ? {...m, points: (m.points||0) + Number(ev.pts||0)} : m );
  save(LS.members, members); renderLeaderboard();
  alert('Đã cộng điểm cho người điểm danh');
}

function createEvent(){
  const name = evtName.value.trim(); const date = evtDate.value; const pts = Number(evtPts.value||20);
  if(!name||!date){ alert('Nhập tên và ngày'); return; }
  events.push({id:'e'+Date.now().toString(36), name, date, pts, attendees:[]}); save(LS.events, events); evtName.value=''; evtDate.value=''; renderEvents();
}

function renderLeaderboard(){
  const top = [...members].sort((a,b)=> (b.points||0)-(a.points||0));
  leaderEl.innerHTML=''; top.forEach((m,i)=>{
    const li = document.createElement('li'); li.className='flex items-center justify-between p-2 rounded border';
    li.innerHTML = `<div class="flex items-center gap-3"><div class="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center font-semibold">${i+1}</div><div><div class="font-medium">${m.name}</div><div class="text-xs text-gray-500">${m.id}</div></div></div><div class="font-semibold">${m.points||0}đ</div>`;
    leaderEl.appendChild(li);
  });
  renderRewards();
}

function renderRewards(){
  rewardsList.innerHTML='';
  rewards.forEach(r=>{
    const div = document.createElement('div'); div.className='flex items-center justify-between p-2 rounded border';
    const left = document.createElement('div'); left.innerHTML = `<div class="font-medium">${r.name}</div><div class="text-xs text-gray-500">${r.cost} điểm</div>`;
    const sel = document.createElement('select'); sel.className='border rounded px-2 py-1'; sel.innerHTML = `<option value="">Chọn người</option>` + members.map(m=>`<option value="${m.id}">${m.name} (${m.points||0}đ)</option>`).join('');
    sel.addEventListener('change', ()=>{
      const pid = sel.value; redeem(pid, r.id);
    });
    div.appendChild(left); div.appendChild(sel);
    rewardsList.appendChild(div);
  });
}

function redeem(pid, rid){
  if(!pid) return;
  const person = members.find(m=>m.id===pid); const reward = rewards.find(r=>r.id===rid);
  if(!person||!reward) return alert('Lỗi');
  if((person.points||0) < reward.cost) return alert('Không đủ điểm');
  members = members.map(m=> m.id===pid? {...m, points: (m.points||0) - reward.cost } : m );
  save(LS.members, members); renderLeaderboard(); alert('Đổi quà thành công: '+reward.name);
}

let chartObj = null;
function renderChart(){
  const ctx = document.getElementById('trashChart').getContext('2d');
  const labels = trash.map(t=>t.date);
  const data = trash.map(t=>t.bags);
  if(chartObj) chartObj.destroy();
  chartObj = new Chart(ctx, {
    type:'bar',
    data:{
      labels,
      datasets:[{ label:'Bao rác', data, backgroundColor: labels.map((l,i)=> trash[i].rain? 'rgba(239,68,68,0.8)':'rgba(34,197,94,0.8)') }]
    },
    options:{ responsive:true, plugins:{ legend:{display:false} } }
  });
}

function updateAvg(){
  const avg = Math.round(spots.reduce((a,b)=>a+(b.level||0),0) / (spots.length||1));
  avgLevelLabel.innerText = `${avg} — ${levelToLabel(avg)}`;
  const badge = document.getElementById('weatherBadge');
  if(settings.badWeather) badge.innerText = 'Cảnh báo: thời tiết xấu';
  else badge.innerText = 'Thời tiết: ổn định';
}

function addFakeTrashDay(){
  const d = new Date(); d.setDate(d.getDate()+1);
  trash.push({date:d.toISOString().slice(5,10), bags: Math.floor(8+Math.random()*35), rain: Math.random()<0.3?Math.floor(5+Math.random()*80):0});
  if(trash.length>30) trash.shift();
  save(LS.trash, trash); renderChart();
}

function clearAllData(){
  if(!confirm('Xóa toàn bộ dữ liệu local?')) return;
  localStorage.clear(); location.reload();
}

function exportData(){
  const obj = {spots, members, events, trash, rewards, settings};
  const blob = new Blob([JSON.stringify(obj, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download='krvt_data.json'; a.click();
  URL.revokeObjectURL(url);
}

document.addEventListener('DOMContentLoaded', ()=>{
  document.getElementById('spotsCount').innerText = spots.length;
  renderSpots(); updateAvg();
  renderMembersCount(); renderEvents(); renderLeaderboard(); renderChart();

  addSpotBtn.addEventListener('click', addSpotFromForm);
  addMemBtn.addEventListener('click', addMember);
  createEvtBtn.addEventListener('click', createEvent);
  addFakeDay.addEventListener('click', ()=>{ addFakeTrashDay(); });
  clearData.addEventListener('click', clearAllData);
  exportBtn.addEventListener('click', exportData);
});
